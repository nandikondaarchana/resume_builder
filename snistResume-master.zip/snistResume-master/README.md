# snistResume
Inizio is a website with a very engaging user interface to help our students prepare a killer resume for the upcoming campus placement season.
Developed by - Students of ECM Department Final Year.
Sreenidhi Institute of Science and Technology
